import logging as log

def log_test(level,file):
    log.basicConfig(level=log.DEBUG,filename=file,filemode="w",format="%(levelname)s %(message)s %(asctime)s") 
    
    if level=="DEBUG": log.debug("Debugging")
    if level=="WARNING": log.warning("Warning")
    if level=="ERROR": log.error("Error")
    if level=="CRITICAL": log.critical("Critical")
    
pass_msg="Passed"

fail_msg="Failed"

for i in range(1,10000):
    print(i)

if __name__=="__main__":
    log_test("DEBUG","E:\Job analyser\log1.log")






