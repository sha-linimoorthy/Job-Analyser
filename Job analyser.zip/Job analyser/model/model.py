# -*- coding: utf-8 -*-
"""
Created on Sun Feb 26 14:31:47 2023

@author: HP
"""

import pickle
from pathlib import Path
from spacy import displacy

path=Path("E:/JBmodel/trained_model.sav")
#save and load the model
load_model=pickle.load(open(path,'rb'))

txt="Communication Skills Data Structures Mathematics Statistics Python technology"

jb=load_model(txt)
colors={'COMPANY':'#fee193', 'LOCATION':'#FCB9AA', 'SALARY':'#9EB9D4', 'SKILLS':'#adb8bb', 'TITLE':'#baedce'}
options={"ents":['COMPANY', 'LOCATION', 'SALARY', 'SKILLS', 'TITLE'],"colors":colors}
html=displacy.render(jb, style="ent",options=options)
print(html)
