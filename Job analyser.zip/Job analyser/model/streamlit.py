# -*- coding: utf-8 -*-
"""
Created on Sun Feb 26 15:01:06 2023

@author: HP
"""


import streamlit as st
import pickle
from spacy import displacy
import pathlib
temp = pathlib.PosixPath
pathlib.PosixPath = pathlib.WindowsPath

path="E:/JBmodel/trained_model.sav"
#save and load the model
load_model=pickle.load(open(path,'rb'))
  
def ner(input_txt):
    
    jb=load_model(input_txt)
    colors={'COMPANY':'#fee193', 'LOCATION':'#FCB9AA', 'SALARY':'#9EB9D4', 'SKILLS':'#adb8bb', 'TITLE':'#baedce'}
    options={"ents":['COMPANY', 'LOCATION', 'SALARY', 'SKILLS', 'TITLE'],"colors":colors}
    ent_html=displacy.render(jb, style="ent",options=options,jupyter=False)
    parse=st.markdown(ent_html, unsafe_allow_html=True)
    return parse
def main():
    parsed=''
    st.title('Job Parser')
    Input=st.text_input('Job Post')       
    if st.button('Parse'):
        parsed=ner(Input)
        st.success('Success')

if __name__=="__main__":
    main()
        