# -*- coding: utf-8 -*-
"""*annotation - txt to JSON, https://tecoholic.github.io/ner-annotator/

JSON to .spacy(binary format) - input format 
pros
* serialization
* fast \*
"""

import spacy
import json
from spacy.tokens import DocBin
from spacy import displacy

path="/content/annotations.json"

#importing the annotated file and storing as train data
with open (path) as fp:
  train_data=json.load(fp)

#load a empty model or edit an existing model

nlp_model=spacy.blank('en') #empty model

db=DocBin()

train_data

from tqdm.notebook import tqdm

for text, annot in tqdm(train_data['annotations']):
    doc = nlp_model.make_doc(text) 
    ents = []
    for start, end, label in annot["entities"]:
        span = doc.char_span(start, end, label=label, alignment_mode="contract")
        if span is None:
            print("Skipping entity")
        else:
            ents.append(span)
    doc.ents = ents 
    db.add(doc)


db.to_disk("./training_data.spacy")

#validation data

path="/content/valid.json"

#importing the annotated file and storing as train data
with open (path) as fp:
  valid_data=json.load(fp)

from tqdm.notebook import tqdm

for text, annot in tqdm(valid_data['annotations']):
    doc = nlp_model.make_doc(text) 
    ents = []
    for start, end, label in annot["entities"]:
        span = doc.char_span(start, end, label=label, alignment_mode="contract")
        if span is None:
            print("Skipping entity")
        else:
            ents.append(span)
    doc.ents = ents 
    db.add(doc)


db.to_disk("./valid_data.spacy")

#https://spacy.io/api/cli#init-fill-config
#configuring the model
python -m spacy init config config.cfg --lang en --pipeline ner --optimize efficiency

#train the model
python -m spacy train config.cfg --output ./ --paths.train ./training_data.spacy --paths.dev ./valid_data.spacy

#testing
job_model=spacy.load("/content/model-best")

txt="Improve job matches What is your ZIP code? 600004 Software Development Manager e24 Technologies Chennai, Tamil Nadu ₹1,00,000 - ₹1,50,000 a month Full-time +1 Day shift A software development manager interfaces between the technical team, the product management team and company leadership.Total work: 10 years (Preferred).PostedPosted 2 days ago"
jb=job_model(text)

for entity in jb.ents:
    print(entity.text, entity.label_)

