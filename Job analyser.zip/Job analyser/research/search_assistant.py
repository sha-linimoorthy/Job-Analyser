#importing modules
from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager   
from selenium.webdriver.chrome.options import Options
import time
import pandas as pd

import logging as log

#logs
def log_test(level,file):
    log.basicConfig(level=log.DEBUG,filename=file,filemode="w",format="%(levelname)s %(message)s %(asctime)s") 
    
    if level=="DEBUG": log.debug("Debugging")
    if level=="WARNING": log.warning("Warning")
    if level=="ERROR": log.error("Error")
    if level=="CRITICAL": log.critical("Critical")
    

#search assistant
link="https://searchassistant.infoassistants.com/"

#setup desired options
options = Options()
options.page_load_strategy = 'normal'

#setup a directory for downloading files
chr_options=webdriver.ChromeOptions()
prefs = {"download.default_directory" : "E:\Job analyser\download"}
chr_options.add_experimental_option("prefs",prefs)

#setupChrome
try:
    drver=webdriver.Chrome(ChromeDriverManager().install(),options=chr_options)
    drver.get(link)
    
except:
    print("Invalid URL")

#File with city names
path="E:\Job analyser\download\cities_fr180.csv"
df=pd.read_csv(path)

#send keys
mail="shalinimoorthy88@gmail.com"
txt="machine learning jobs"


def auto_fill():
#fetching data for all cities and filling
    if(True):
        for i in df.index:
            entry=df.loc[i]
#auto fill mail
            fill_mail=drver.find_element_by_id("email")
            fill_mail.send_keys(mail)
            drver.set_page_load_timeout(5)
            
    
#auto fill text
            fill_text=drver.find_element_by_id("query")
            fill_text.send_keys(txt,"+",entry['city'])
            
    
#submit
            submit=drver.find_element_by_id("submit_button")
            submit.click()
            drver.set_page_load_timeout(20)
            time.sleep(10)
            crr_url=drver.current_url
            url="https://searchassistant.infoassistants.com/next"
    
            if crr_url==url:
#download
                time.sleep(10)
                drver.refresh()    
                drver.set_page_load_timeout(10)
                dwnld=drver.find_element_by_class_name("dt-button")
                dwnld.click()
        
#return
            drver.back()
            drver.refresh()    
            time.sleep(10)
auto_fill()
    
drver.quit()

if __name__=="__main__":
    log_test("DEBUG","E:\Job analyser\log1.log")
else:
    quit()
        
    

